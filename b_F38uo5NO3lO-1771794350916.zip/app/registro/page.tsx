import { RegisterForm } from '@/components/auth/register-form'

export default function RegistroPage() {
  return <RegisterForm />
}
